<?php 
	/*Enter your API_KEY*/
	define("API_KEY", 'PT+SuXsNwGs-68D70h3zQZjAeiT1zUrWtLuqdBpiks');
	/*You can enter mobile number here*/
	define("MOBILE", '8700380233');
 ?>
